﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using sugar_babys.Screens;

namespace sugar_babys
{
    public partial class MainScreen : Form
    {
        public Database db = new Database();
        public Order order = new Order();
        public int orderID = 0;

        public MainScreen()
        {
            InitializeComponent();
            AdjustScreen();
        }

        private void AdjustScreen()
        {
            double w = this.Width;
            double h = this.Height;
            if (w > 1050)
            {
                dgv.Width = (int)(w - 175);

                btnInventory.Left = (int)(w - 285);
                btnEmployees.Left = (int)(w - 285);
                btnReports.Left = (int)(w - 285);
            }
            if (w > 1040)
            {
                btnDeleteOrder.Left = (int)(w - (w * .25));
                btnNewOrder.Left = btnDeleteOrder.Left - 168;
            }
            dgv.Height = (int)((h - dgv.Top) - (h * .08));
        }

        private void MainScreen_Resize(object sender, EventArgs e)
        {
            AdjustScreen();
        }

        private void btnNewCustomer_Click(object sender, EventArgs e)
        {
            CustomerScreen customerScreen = new CustomerScreen(db.dtCustomers);
            customerScreen.ShowDialog();
        }

        private void btnEditCustomer_Click(object sender, EventArgs e)
        {
            // build customer
            BasePerson person = new BasePerson();
            Customer customer = new Customer(person);
            DataRow row = ((DataTable)cboCustomer.DataSource).Rows[cboCustomer.SelectedIndex];
            customer.setID((int)row["id"]);
            customer.setName((string)row["name"]);
            customer.setAddress1((string)row["address1"]);
            customer.setAddress2((string)row["address2"]);
            customer.setCity((string)row["city"]);
            customer.setState((string)row["state"]);
            customer.setZip((int)row["zip"]);
            customer.setPhone(Int64.Parse(row["phone"].ToString()));
            customer.setEmail((string)row["email"]);
            customer.setContact((string)row["contact"]);
            customer.setContactPhone(Int64.Parse(row["contactPhone"].ToString()));
            customer.setContactEmail((string)row["contactEmail"]);
            customer.setAnniversary((DateTime)row["anniversary"]);
            customer.setLastUpdated((DateTime)row["lastUpdated"]);

            // load customer screen
            CustomerScreen customerScreen = new CustomerScreen(db.dtCustomers, 
                customer);
            customerScreen.ShowDialog();
        }

        private void cboCustomer_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboCustomer.SelectedIndex > -1)
            {
                DataRow row = ((DataTable)cboCustomer.DataSource).Rows[cboCustomer.SelectedIndex];
                db.GetOrders((int)row["id"]);
                dgv.DataSource = db.dtCustomerOrders;
                db.formatDGV(dgv);
                btnEditCustomer.Enabled = true;
            }
        }

        private void dgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgv.CurrentCell != null)
            {
                DataRow row = ((DataTable)dgv.DataSource).Rows[dgv.CurrentCell.RowIndex];
                orderID = (int)row["id"];
                dgv.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.Yellow;
                btnDeleteOrder.Enabled = true;
                btnDeleteOrder.Enabled = true;
            }
        }

        private void MainScreen_Load(object sender, EventArgs e)
        {
            dgv.Refresh();
        }

        private void btnEmployees_Click(object sender, EventArgs e)
        {
            db.GetEmployees();
            EmployeeScreen employeeScreen = new EmployeeScreen(db.dtEmployees);
            employeeScreen.ShowDialog();
        }

        private void btnInventory_Click(object sender, EventArgs e)
        {
            db.GetInventory();
            InventoryScreen inventoryScreen = new InventoryScreen(db.dtInventory);
            inventoryScreen.ShowDialog();
        }

        private void btnNewOrder_Click(object sender, EventArgs e)
        {
            db.GetInventory();
            OrderScreen orderScreen = new OrderScreen(db.dtCustomers, db.dtInventory);
            orderScreen.ShowDialog();
        }

        private void MainScreen_Activated(object sender, EventArgs e)
        {
            cboCustomer.DataSource = null;
            db.GetCustomers();
            cboCustomer.DataSource = db.dtCustomers;
            cboCustomer.DisplayMember = "name";
            btnDeleteOrder.Enabled = false;
            if (cboCustomer.Items.Count < 1)
            {
                btnEditCustomer.Enabled = false;
            }
        }

        private void btnReports_Click(object sender, EventArgs e)
        {
            ReportScreen reportScreen = new ReportScreen();
            reportScreen.ShowDialog();
        }

        private void btnDeleteOrder_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to delete the selected order?" , 
                "Delete?", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                db.DeleteOrder(orderID);
                dgv.DataSource = null;
                DataRow row = ((DataTable)cboCustomer.DataSource).Rows[cboCustomer.SelectedIndex];
                db.GetOrders((int)row["id"]);
                dgv.DataSource = db.dtCustomerOrders;
            }

        }

        private void btnLogo_MouseClick(object sender, MouseEventArgs e)
        {
            if (btnTest.Visible)
            {
                btnTest.Visible = false;
            }
            else
            {
                btnTest.Visible = true;
            }
        }

        // ***** btnTest is for testing purposes only *****
        private void btnTest_Click(object sender, EventArgs e)
        {
            TestScreen testScreen = new TestScreen();
            testScreen.ShowDialog();
        }
    }
}
