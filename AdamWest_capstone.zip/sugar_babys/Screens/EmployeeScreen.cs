﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sugar_babys.Screens
{
    public partial class EmployeeScreen : Form
    {
        bool[] blnValid = new bool[10];
        static BasePerson person = new BasePerson();
        public Employee employee = new Employee(person);
        public Database db = new Database();
        // tooltips
        ToolTip tipName = new ToolTip();
        ToolTip tipEmail = new ToolTip();
        ToolTip tipPhone = new ToolTip();
        ToolTip tipAddress = new ToolTip();
        ToolTip tipAddress2 = new ToolTip();
        ToolTip tipCity = new ToolTip();
        ToolTip tipState = new ToolTip();
        ToolTip tipZip = new ToolTip();
        ToolTip tipJobTitle = new ToolTip();
        ToolTip tipSalary = new ToolTip();

        public EmployeeScreen(DataTable dt)
        {
            InitializeComponent();

            dgv.DataSource = dt;
            db.formatDGV(dgv);
            populateStates();
            btnDelete.Enabled = false;
        }

        public EmployeeScreen(DataTable dt, Employee employee)
        {
            InitializeComponent();
            this.employee = employee;
            dgv.DataSource = dt;
            db.formatDGV(dgv);
            populateStates();
            populateForm();
        }

        private void populateStates()
        {
            cboState.Items.Add("Alabama - AL");
            cboState.Items.Add("Alaska - AK");
            cboState.Items.Add("Arizona - AZ");
            cboState.Items.Add("Arkansas - AR");
            cboState.Items.Add("California - CA");
            cboState.Items.Add("Colorado - CO");
            cboState.Items.Add("Connecticut - CT");
            cboState.Items.Add("Delaware - DE");
            cboState.Items.Add("Florida - FL");
            cboState.Items.Add("Georgia - GA");
            cboState.Items.Add("Hawaii - HI");
            cboState.Items.Add("Idaho - ID");
            cboState.Items.Add("Illinois - IL");
            cboState.Items.Add("Indiana - IN");
            cboState.Items.Add("Iowa - IA");
            cboState.Items.Add("Kansas - KS");
            cboState.Items.Add("Kentucky - KY");
            cboState.Items.Add("Louisiana - LA");
            cboState.Items.Add("Maine - ME");
            cboState.Items.Add("Maryland - MD");
            cboState.Items.Add("Massachusetts - MA");
            cboState.Items.Add("Michigan - MI");
            cboState.Items.Add("Minnesota - MN");
            cboState.Items.Add("Mississippi - MS");
            cboState.Items.Add("Missouri - MO");
            cboState.Items.Add("Montana - MT");
            cboState.Items.Add("Nebraska - NE");
            cboState.Items.Add("Nevada - NV");
            cboState.Items.Add("New Hampshire - NH");
            cboState.Items.Add("New Jersey - NJ");
            cboState.Items.Add("New Mexico - NM");
            cboState.Items.Add("New York - NY");
            cboState.Items.Add("North Carolina - NC");
            cboState.Items.Add("North Dakota - ND");
            cboState.Items.Add("Ohio - OH");
            cboState.Items.Add("Oklahoma - OK");
            cboState.Items.Add("Oregon - OR");
            cboState.Items.Add("Pennsylvania - PA");
            cboState.Items.Add("Rhode Island - RI");
            cboState.Items.Add("South Carolina - SC");
            cboState.Items.Add("South Dakota - SD");
            cboState.Items.Add("Tennessee - TN");
            cboState.Items.Add("Texas - TX");
            cboState.Items.Add("Utah - UT");
            cboState.Items.Add("Vermont - VT");
            cboState.Items.Add("Virginia - VA");
            cboState.Items.Add("Washington - WA");
            cboState.Items.Add("West Virginia - WV");
            cboState.Items.Add("Wisconsin - WI");
            cboState.Items.Add("Wyoming - WY");
        }

        private void populateForm()
        {
            txtName.Text = employee.getName();
            txtAddress.Text = employee.getAddress1();
            txtAddress2.Text = employee.getAddress2();
            txtCity.Text = employee.getCity();
            cboState.SelectedItem = employee.getState();
            txtZip.Text = employee.getZip().ToString();
            if (txtZip.Text == "0") { txtZip.Text = ""; }
            txtPhone.Text = employee.getPhone().ToString();
            if (txtPhone.Text == "0") { txtPhone.Text = ""; }
            txtEmail.Text = employee.getEmail();
            txtJobTitle.Text = employee.getJobTitle();
            txtSalary.Text = employee.getSalary().ToString();
            if (txtSalary.Text == "0") { txtSalary.Text = ""; }
        }

        private void updateData()
        {
            employee.setName(txtName.Text);
            employee.setAddress1(txtAddress.Text);
            employee.setAddress2(txtAddress2.Text);
            employee.setCity(txtCity.Text);
            employee.setState(cboState.SelectedItem.ToString());
            employee.setZip(Int32.Parse(txtZip.Text));
            employee.setPhone(Int64.Parse(txtPhone.Text));
            employee.setEmail(txtEmail.Text);
            employee.setJobTitle(txtJobTitle.Text);
            employee.setSalary(Double.Parse(txtSalary.Text));
        }

        public void buildEmployee()
        {
            // build employee
            employee = new Employee(person);
            DataRow row = ((DataTable)dgv.DataSource).Rows[dgv.CurrentCell.RowIndex];
            employee.setID((int)row["id"]);
            employee.setName((string)row["name"]);
            employee.setAddress1((string)row["address1"]);
            employee.setAddress2((string)row["address2"]);
            employee.setCity((string)row["city"]);
            employee.setState((string)row["state"]);
            employee.setZip((int)row["zip"]);
            employee.setPhone(Int64.Parse(row["phone"].ToString()));
            employee.setEmail((string)row["email"]);
            employee.setJobTitle((string)row["jobTitle"]);
            employee.setSalary(Double.Parse(row["salary"].ToString()));
            employee.setAnniversary((DateTime)row["anniversary"]);
            employee.setLastUpdated((DateTime)row["lastUpdated"]);
        }

        public void resetForm()
        {
            if (txtName.Text.Trim() != "" || txtPhone.Text.Trim() != "" || txtEmail.Text.Trim() != "" ||
                txtAddress.Text.Trim() != "" || txtAddress2.Text.Trim() != "" || txtCity.Text.Trim() != "" ||
                cboState.SelectedIndex > 0 || txtZip.Text.Trim() != "" || txtJobTitle.Text.Trim() != "" ||
                txtSalary.Text.Trim() != "")
            {
                DialogResult result = MessageBox.Show("Are you sure you want to reset the form?", "Reset?",
                    MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    employee = new Employee(person);
                    populateForm();
                    dgv.ClearSelection();
                    btnDelete.Enabled = false;
                }
            }
            else
            {
                employee = new Employee(person);
                populateForm();
                dgv.ClearSelection();
                btnDelete.Enabled = false;
            }
        }

        private bool validateForm()
        {
            // validate name
            if (!validateText(txtName.Text))
            {
                txtName.BackColor = System.Drawing.Color.LightSalmon;
                tipName.SetToolTip(txtName, "Please enter letters and numbers only");
                blnValid[0] = false;
            }
            else
            {
                txtName.BackColor = System.Drawing.Color.White;
                tipName.RemoveAll();
                blnValid[0] = true;
            }
            // validate email
            if (!validateEmail(txtEmail.Text))
            {
                txtEmail.BackColor = System.Drawing.Color.LightSalmon;
                tipEmail.SetToolTip(txtEmail, "Please enter a valid email address (sample@email.com)");
                blnValid[1] = false;
            }
            else
            {
                txtEmail.BackColor = System.Drawing.Color.White;
                tipEmail.RemoveAll();
                blnValid[1] = true;
            }
            // validate phone
            if (!validatePhone(txtPhone.Text))
            {
                txtPhone.BackColor = System.Drawing.Color.LightSalmon;
                tipPhone.SetToolTip(txtPhone, "Please enter 10 numbers only");
                blnValid[2] = false;
            }
            else
            {
                txtPhone.BackColor = System.Drawing.Color.White;
                tipPhone.RemoveAll();
                blnValid[2] = true;
            }
            // validate address
            if (!validateText(txtAddress.Text))
            {
                txtAddress.BackColor = System.Drawing.Color.LightSalmon;
                tipAddress.SetToolTip(txtAddress, "Please enter letters and numbers only");
                blnValid[3] = false;
            }
            else
            {
                txtAddress.BackColor = System.Drawing.Color.White;
                tipAddress.RemoveAll();
                blnValid[3] = true;
            }
            // validate address2
            if (txtAddress2.Text.Trim() != "")
            {
                if (!validateText(txtAddress.Text))
                {
                    txtAddress2.BackColor = System.Drawing.Color.LightSalmon;
                    tipAddress2.SetToolTip(txtAddress2, "Please enter letters and numbers only");
                    blnValid[4] = false;
                }
                else
                {
                    txtAddress2.BackColor = System.Drawing.Color.White;
                    tipAddress2.RemoveAll();
                    blnValid[4] = true;
                }
            }
            // validate city
            if (!validateText(txtCity.Text))
            {
                txtCity.BackColor = System.Drawing.Color.LightSalmon;
                tipCity.SetToolTip(txtCity, "Please enter letters and numbers only");
                blnValid[5] = false;
            }
            else
            {
                txtCity.BackColor = System.Drawing.Color.White;
                tipCity.RemoveAll();
                blnValid[5] = true;
            }
            // validate state
            if (cboState.SelectedIndex < 0)
            {
                cboState.BackColor = System.Drawing.Color.LightSalmon;
                tipState.SetToolTip(txtCity, "Please select a state");
                blnValid[6] = false;
            }
            else
            {
                cboState.BackColor = System.Drawing.Color.White;
                tipState.RemoveAll();
                blnValid[6] = true;
            }
            // validate zip
            if (!validateZip(txtZip.Text))
            {
                txtZip.BackColor = System.Drawing.Color.LightSalmon;
                tipZip.SetToolTip(txtZip, "Please enter 5 to 15 numbers only");
                blnValid[7] = false;
            }
            else
            {
                txtZip.BackColor = System.Drawing.Color.White;
                tipZip.RemoveAll();
                blnValid[7] = true;
            }
            // validate job title
            if (!validateText(txtJobTitle.Text))
            {
                txtJobTitle.BackColor = System.Drawing.Color.LightSalmon;
                tipJobTitle.SetToolTip(txtJobTitle, "Please enter letters and numbers only");
                blnValid[8] = false;
            }
            else
            {
                txtJobTitle.BackColor = System.Drawing.Color.White;
                tipJobTitle.RemoveAll();
                blnValid[8] = true;
            }
            // validate salary
            if (!validateSalary(txtSalary.Text))
            {
                txtSalary.BackColor = System.Drawing.Color.LightSalmon;
                tipSalary.SetToolTip(txtSalary, "Please enter numbers only");
                blnValid[9] = false;
            }
            else
            {
                txtSalary.BackColor = System.Drawing.Color.White;
                tipSalary.RemoveAll();
                blnValid[9] = true;
            }

            for (int i = 0; i < 10; i++)
            {
                if (!blnValid[i])
                {
                    return false;
                }
            }
            return true;
        }

        private bool validateZip(string zip)
        {
            // verify the zip is not empty
            if (!String.IsNullOrEmpty(zip))
            {
                // verify between 5 and 15 characters
                if (zip.Length >= 5 && zip.Length <= 15)
                {
                    for (int i = 0; i < zip.Length; i++)
                    {
                        // verify only numbers were entered
                        if (!char.IsDigit(zip[i]))
                        {
                            return false;
                        }
                    }
                    return true;
                }
            }
            return false;
        }

        private bool validateSalary(string salary)
        {
            // verify the zip is not empty
            if (!String.IsNullOrEmpty(salary))
            {
                for (int i = 0; i < salary.Length; i++)
                {
                    // verify only numbers were entered
                    if (!char.IsDigit(salary[i]))
                    {
                        return false;
                    }
                }
                return true;
            }
            return false;
        }

        private bool validatePhone(string phone)
        {
            // verify the phone is not empty
            if (!String.IsNullOrEmpty(phone))
            {
                // verify 10 characters
                if (phone.Length == 10)
                {
                    for (int i = 0; i < phone.Length; i++)
                    {
                        // verify only numbers were entered
                        if (!char.IsDigit(phone[i]))
                        {
                            return false;
                        }
                    }
                    return true;
                }
            }
            return false;
        }

        private bool validateEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }

        private bool validateText(string text)
        {
            // verify the text is not empty
            if (!String.IsNullOrEmpty(text))
            {
                for (int i = 0; i < text.Length; i++)
                {
                    // verify only letters and numbers were entered
                    if (!char.IsLetterOrDigit(text[i]))
                    {
                        if (!char.IsWhiteSpace(text[i]))
                        {
                            return false;
                        }
                    }
                }
                return true;
            }
            return false;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (validateForm())
            {
                if (employee.getID() > 0)
                {
                    // update record
                    updateData();
                    db.UpdateEmployee(employee);
                }
                else
                {
                    // create record
                    updateData();
                    db.AddEmployee(employee);
                }
                // refresh datatable & dgv
                db.GetEmployees();
                dgv.DataSource = db.dtEmployees;
                db.selectDGV(dgv, employee);
                btnDelete.Enabled = true;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgv.CurrentCell != null)
            {
                dgv.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.Yellow;
                buildEmployee();
                populateForm();
                btnDelete.Enabled = true;
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            db.searchDGV(dgv, txtSearch.Text);
            if (dgv.CurrentCell != null)
            {
                buildEmployee();
                populateForm();
                btnDelete.Enabled = true;
            }
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            resetForm();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            resetForm();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to delete the selected employee?"
                , "Delete?", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                db.DeleteEmployee(employee);
                employee = new Employee(person);
                db.dtEmployees = new DataTable();
                db.GetEmployees();
                dgv.ClearSelection();
                dgv.DataSource = null;
                dgv.Refresh();
                dgv.DataSource = db.dtEmployees;
                db.formatDGV(dgv);
                populateForm();
                btnDelete.Enabled = false;
            }
        }
    }
}
