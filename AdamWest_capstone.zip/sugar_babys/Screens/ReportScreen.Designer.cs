﻿
namespace sugar_babys.Screens
{
    partial class ReportScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabReports = new System.Windows.Forms.TabControl();
            this.rOrderDetails = new System.Windows.Forms.TabPage();
            this.txtOrderDetails = new System.Windows.Forms.TextBox();
            this.rEmployeeList = new System.Windows.Forms.TabPage();
            this.txtEmployeeList = new System.Windows.Forms.TextBox();
            this.rCustomerList = new System.Windows.Forms.TabPage();
            this.txtCustomerList = new System.Windows.Forms.TextBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.tabReports.SuspendLayout();
            this.rOrderDetails.SuspendLayout();
            this.rEmployeeList.SuspendLayout();
            this.rCustomerList.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabReports
            // 
            this.tabReports.Controls.Add(this.rOrderDetails);
            this.tabReports.Controls.Add(this.rEmployeeList);
            this.tabReports.Controls.Add(this.rCustomerList);
            this.tabReports.Location = new System.Drawing.Point(18, 22);
            this.tabReports.Name = "tabReports";
            this.tabReports.SelectedIndex = 0;
            this.tabReports.Size = new System.Drawing.Size(765, 416);
            this.tabReports.TabIndex = 0;
            // 
            // rOrderDetails
            // 
            this.rOrderDetails.Controls.Add(this.txtOrderDetails);
            this.rOrderDetails.Location = new System.Drawing.Point(4, 24);
            this.rOrderDetails.Name = "rOrderDetails";
            this.rOrderDetails.Padding = new System.Windows.Forms.Padding(3);
            this.rOrderDetails.Size = new System.Drawing.Size(757, 388);
            this.rOrderDetails.TabIndex = 0;
            this.rOrderDetails.Text = "Order Details";
            this.rOrderDetails.UseVisualStyleBackColor = true;
            // 
            // txtOrderDetails
            // 
            this.txtOrderDetails.Location = new System.Drawing.Point(3, 3);
            this.txtOrderDetails.Multiline = true;
            this.txtOrderDetails.Name = "txtOrderDetails";
            this.txtOrderDetails.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtOrderDetails.Size = new System.Drawing.Size(750, 382);
            this.txtOrderDetails.TabIndex = 1;
            // 
            // rEmployeeList
            // 
            this.rEmployeeList.Controls.Add(this.txtEmployeeList);
            this.rEmployeeList.Location = new System.Drawing.Point(4, 24);
            this.rEmployeeList.Name = "rEmployeeList";
            this.rEmployeeList.Padding = new System.Windows.Forms.Padding(3);
            this.rEmployeeList.Size = new System.Drawing.Size(757, 388);
            this.rEmployeeList.TabIndex = 1;
            this.rEmployeeList.Text = "Employee List";
            this.rEmployeeList.UseVisualStyleBackColor = true;
            // 
            // txtEmployeeList
            // 
            this.txtEmployeeList.Location = new System.Drawing.Point(3, 3);
            this.txtEmployeeList.Multiline = true;
            this.txtEmployeeList.Name = "txtEmployeeList";
            this.txtEmployeeList.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtEmployeeList.Size = new System.Drawing.Size(750, 382);
            this.txtEmployeeList.TabIndex = 2;
            // 
            // rCustomerList
            // 
            this.rCustomerList.Controls.Add(this.txtCustomerList);
            this.rCustomerList.Location = new System.Drawing.Point(4, 24);
            this.rCustomerList.Name = "rCustomerList";
            this.rCustomerList.Padding = new System.Windows.Forms.Padding(3);
            this.rCustomerList.Size = new System.Drawing.Size(757, 388);
            this.rCustomerList.TabIndex = 2;
            this.rCustomerList.Text = "Customer List";
            this.rCustomerList.UseVisualStyleBackColor = true;
            // 
            // txtCustomerList
            // 
            this.txtCustomerList.Location = new System.Drawing.Point(4, 3);
            this.txtCustomerList.Multiline = true;
            this.txtCustomerList.Name = "txtCustomerList";
            this.txtCustomerList.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtCustomerList.Size = new System.Drawing.Size(750, 382);
            this.txtCustomerList.TabIndex = 0;
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnClose.Font = new System.Drawing.Font("Kristen ITC", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnClose.Location = new System.Drawing.Point(678, 9);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(97, 31);
            this.btnClose.TabIndex = 73;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // ReportScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.tabReports);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MaximizeBox = false;
            this.Name = "ReportScreen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Reports";
            this.tabReports.ResumeLayout(false);
            this.rOrderDetails.ResumeLayout(false);
            this.rOrderDetails.PerformLayout();
            this.rEmployeeList.ResumeLayout(false);
            this.rEmployeeList.PerformLayout();
            this.rCustomerList.ResumeLayout(false);
            this.rCustomerList.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabReports;
        private System.Windows.Forms.TabPage rOrderDetails;
        private System.Windows.Forms.TabPage rEmployeeList;
        private System.Windows.Forms.TabPage rCustomerList;
        private System.Windows.Forms.TextBox txtCustomerList;
        private System.Windows.Forms.TextBox txtOrderDetails;
        private System.Windows.Forms.TextBox txtEmployeeList;
        private System.Windows.Forms.Button btnClose;
    }
}