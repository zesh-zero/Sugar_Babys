﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sugar_babys.Screens
{
    public partial class TestScreen : Form
    {
        // ***** all following code is for testing purposes only *****
        public TestScreen()
        {
            InitializeComponent();
            runTest();
        }

        private void runTest()
        {
            Database testDB = new Database();
            testDB.GetDatabase();
            txtTest.Text = "SELECT * FROM customers;\r\n\t";
            txtTest.Text = txtTest.Text + "count = " + testDB.dtCustomers.Rows.Count.ToString() + "\r\n\r\n\t";
            foreach (DataRow row in testDB.dtCustomers.Rows)
            {
                // output customers table data
                txtTest.Text = txtTest.Text + "\tid: " + row["id"] + " | ";
                txtTest.Text = txtTest.Text + "name: " + row["name"] + " | ";
                txtTest.Text = txtTest.Text + "address1: " + row["address1"] + " | ";
                txtTest.Text = txtTest.Text + "address2: " + row["address2"] + " | ";
                txtTest.Text = txtTest.Text + "city: " + row["city"] + " | ";
                txtTest.Text = txtTest.Text + "state: " + row["state"] + " | ";
                txtTest.Text = txtTest.Text + "zip: " + row["zip"] + " | ";
                txtTest.Text = txtTest.Text + "phone: " + row["phone"] + " | ";
                txtTest.Text = txtTest.Text + "email: " + row["email"] + " | ";
                txtTest.Text = txtTest.Text + "contact: " + row["contact"] + " | ";
                txtTest.Text = txtTest.Text + "contactPhone: " + row["contactPhone"] + " | ";
                txtTest.Text = txtTest.Text + "contactEmail: " + row["contactEmail"] + " | ";
                txtTest.Text = txtTest.Text + "anniversary: " + row["anniversary"] + " | ";
                txtTest.Text = txtTest.Text + "lastUpdated: " + row["lastUpdated"] + "\r\n\t";
            }
            txtTest.Text = txtTest.Text + "\r\nSELECT * FROM employees;\r\n\t";
            txtTest.Text = txtTest.Text + "count = " + testDB.dtEmployees.Rows.Count.ToString() + "\r\n\r\n\t";
            foreach (DataRow row in testDB.dtEmployees.Rows)
            {
                // output employees table data
                txtTest.Text = txtTest.Text + "\tid: " + row["id"] + " | ";
                txtTest.Text = txtTest.Text + "name: " + row["name"] + " | ";
                txtTest.Text = txtTest.Text + "address1: " + row["address1"] + " | ";
                txtTest.Text = txtTest.Text + "address2: " + row["address2"] + " | ";
                txtTest.Text = txtTest.Text + "city: " + row["city"] + " | ";
                txtTest.Text = txtTest.Text + "state: " + row["state"] + " | ";
                txtTest.Text = txtTest.Text + "zip: " + row["zip"] + " | ";
                txtTest.Text = txtTest.Text + "phone: " + row["phone"] + " | ";
                txtTest.Text = txtTest.Text + "email: " + row["email"] + " | ";
                txtTest.Text = txtTest.Text + "jobTitle: " + row["jobTitle"] + " | ";
                txtTest.Text = txtTest.Text + "salary: " + row["salary"] + " | ";
                txtTest.Text = txtTest.Text + "anniversary: " + row["anniversary"] + " | ";
                txtTest.Text = txtTest.Text + "lastUpdated: " + row["lastUpdated"] + "\r\n\t";
            }
            txtTest.Text = txtTest.Text + "\r\nSELECT * FROM inventory;\r\n\t";
            txtTest.Text = txtTest.Text + "count = " + testDB.dtInventory.Rows.Count.ToString() + "\r\n\r\n\t";
            foreach (DataRow row in testDB.dtInventory.Rows)
            {
                // output inventory table data
                txtTest.Text = txtTest.Text + "\tid: " + row["id"] + " | ";
                txtTest.Text = txtTest.Text + "name: " + row["name"] + " | ";
                txtTest.Text = txtTest.Text + "description: " + row["description"] + " | ";
                txtTest.Text = txtTest.Text + "type: " + row["type"] + " | ";
                txtTest.Text = txtTest.Text + "vendor: " + row["vendor"] + " | ";
                txtTest.Text = txtTest.Text + "cost: " + row["cost"] + " | ";
                txtTest.Text = txtTest.Text + "price: " + row["price"] + " | ";
                txtTest.Text = txtTest.Text + "qty: " + row["qty"] + " | ";
                txtTest.Text = txtTest.Text + "firstPurchase: " + row["firstPurchase"] + " | ";
                txtTest.Text = txtTest.Text + "lastPurchase: " + row["lastPurchase"] + "\r\n\t";
            }
            txtTest.Text = txtTest.Text + "\r\nSELECT * FROM orders;\r\n\t";
            txtTest.Text = txtTest.Text + "count = " + testDB.dtOrders.Rows.Count.ToString() + "\r\n";
            foreach (DataRow row in testDB.dtOrders.Rows)
            {
                // output order table data
                txtTest.Text = txtTest.Text + "\r\n\t\tid: " + row["id"] + " | ";
                txtTest.Text = txtTest.Text + "cusID: " + row["cusID"] + " | ";
                txtTest.Text = txtTest.Text + "subtotal: " + row["subtotal"] + " | ";
                txtTest.Text = txtTest.Text + "adjustment: " + row["adjustment"] + " | ";
                txtTest.Text = txtTest.Text + "tax: " + row["tax"] + " | ";
                txtTest.Text = txtTest.Text + "total: " + row["total"] + " | ";
                txtTest.Text = txtTest.Text + "notes: " + row["notes"] + " | ";
                txtTest.Text = txtTest.Text + "purchaseDate: " + row["purchaseDate"] + "\r\n\t";

                // ouput order details table data
                txtTest.Text = txtTest.Text + "\r\n\t\tSELECT * FROM orderDetails;\r\n\r\n";
                testDB.GetOrderDetails((int)row["id"]);
                // output order details table data
                foreach (DataRow detail in testDB.dtOrderDetails.Rows)
                {
                    txtTest.Text = txtTest.Text + "\t\t\t\tinvID: " + detail["invID"] + " | ";
                    txtTest.Text = txtTest.Text + "ordID: " + detail["ordID"] + " | ";
                    txtTest.Text = txtTest.Text + "qty: " + detail["qty"] + "\r\n\t";
                }
            }
            // print footer
            txtTest.Text = txtTest.Text + "\r\n\r\n\r\n*End of Test";
        }
    }
}
