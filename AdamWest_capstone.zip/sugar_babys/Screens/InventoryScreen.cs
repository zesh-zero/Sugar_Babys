﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sugar_babys.Screens
{
    public partial class InventoryScreen : Form
    {
        bool[] blnValid = new bool[7];
        Database db = new Database();
        DataTable dtInventory = new DataTable();
        Candy candy = new Candy();
        // tooltips
        ToolTip tipName = new ToolTip();
        ToolTip tipType = new ToolTip();
        ToolTip tipDescription = new ToolTip();
        ToolTip tipVendor = new ToolTip();
        ToolTip tipCost = new ToolTip();
        ToolTip tipQty = new ToolTip();
        ToolTip tipPrice = new ToolTip();

        public InventoryScreen(DataTable inventory)
        {
            InitializeComponent();

            dtInventory = inventory;
            dgv.DataSource = dtInventory;
            db.formatDGV(dgv);
            btnDelete.Enabled = false;
        }

        private void dgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgv.CurrentCell != null)
            {
                dgv.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.Yellow;
                buildCandy();
                populateForm();
                btnDelete.Enabled = true;
            }
        }

        public void buildCandy()
        {
            // build candy
            candy = new Candy();
            DataRow row = ((DataTable)dgv.DataSource).Rows[dgv.CurrentCell.RowIndex];
            candy.id = (int)row["id"];
            candy.name = (string)row["name"];
            candy.description = (string)row["description"];
            candy.type = (string)row["type"];
            candy.vendor = (string)row["vendor"];
            candy.cost = (double)row["cost"];
            candy.price = (double)row["price"];
            candy.quantity = (int)row["qty"];
            candy.firstPurchase = (DateTime)row["firstPurchase"];
            candy.lastPurchase = (DateTime)row["lastPurchase"];
        }

        public Candy buildCandy(string name)
        {
            // build candy
            candy = new Candy();
            candy.name = txtName.Text;
            candy.description = txtDescription.Text;
            candy.type = txtType.Text;
            candy.vendor = txtVendor.Text;
            candy.cost = double.Parse(txtCost.Text);
            candy.price = double.Parse(txtPrice.Text);
            candy.quantity = Int32.Parse(txtQty.Text);
            return candy;
        }

        public void updateCandy()
        {
            // update candy
            candy.name = txtName.Text;
            candy.description = txtDescription.Text;
            candy.type = txtType.Text;
            candy.vendor = txtVendor.Text;
            candy.cost = double.Parse(txtCost.Text);
            candy.price = double.Parse(txtPrice.Text);
            candy.quantity = Int32.Parse(txtQty.Text);
        }

        private void populateForm()
        {
            txtName.Text = candy.name;
            txtDescription.Text = candy.description;
            txtType.Text = candy.type;
            txtVendor.Text = candy.vendor;
            if (candy.cost == 0) { txtCost.Text = ""; } else { txtCost.Text = candy.cost.ToString(); }
            if (candy.price == 0) { txtPrice.Text = ""; } else { txtPrice.Text = candy.price.ToString(); }
            if (candy.quantity == 0) { txtQty.Text = ""; } else { txtQty.Text = candy.quantity.ToString(); }
        }

        public void resetForm()
        {
            if (txtName.Text.Trim() != "" || txtDescription.Text.Trim() != "" || txtType.Text.Trim() != "" ||
                txtQty.Text.Trim() != "" || txtVendor.Text.Trim() != "" || txtCost.Text.Trim() != "" ||
                txtPrice.Text != "")
            {
                DialogResult result = MessageBox.Show("Are you sure you want to reset the form?", "Reset?",
                    MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    candy = new Candy();
                    populateForm();
                    dgv.ClearSelection();
                    btnDelete.Enabled = false;
                }
            }
            else
            {
                candy = new Candy();
                populateForm();
                dgv.ClearSelection();
            }
        }

        private bool validateText(string text)
        {
            // verify the text is not empty
            if (!String.IsNullOrEmpty(text))
            {
                for (int i = 0; i < text.Length; i++)
                {
                    // verify only letters and numbers were entered
                    if (!char.IsLetterOrDigit(text[i]))
                    {
                        if (!char.IsWhiteSpace(text[i]))
                        {
                            return false;
                        }
                    }
                }
                return true;
            }
            return false;
        }

        private bool validateForm()
        {
            // validate name
            if (!validateText(txtName.Text))
            {
                txtName.BackColor = System.Drawing.Color.LightSalmon;
                tipName.SetToolTip(txtName, "Please enter letters and numbers only");
                blnValid[0] = false;
            }
            else
            {
                txtName.BackColor = System.Drawing.Color.White;
                tipName.RemoveAll();
                blnValid[0] = true;
            }
            // validate type
            if (!validateText(txtType.Text))
            {
                txtType.BackColor = System.Drawing.Color.LightSalmon;
                tipType.SetToolTip(txtType, "Please enter letters and numbers only");
                blnValid[1] = false;
            }
            else
            {
                txtType.BackColor = System.Drawing.Color.White;
                tipType.RemoveAll();
                blnValid[1] = true;
            }
            // validate description
            if (!validateText(txtDescription.Text))
            {
                txtDescription.BackColor = System.Drawing.Color.LightSalmon;
                tipDescription.SetToolTip(txtDescription, "Please enter letters and numbers only");
                blnValid[2] = false;
            }
            else
            {
                txtDescription.BackColor = System.Drawing.Color.White;
                tipDescription.RemoveAll();
                blnValid[2] = true;
            }
            // validate vendor
            if (!validateText(txtVendor.Text))
            {
                txtVendor.BackColor = System.Drawing.Color.LightSalmon;
                tipVendor.SetToolTip(txtVendor, "Please enter letters and numbers only");
                blnValid[3] = false;
            }
            else
            {
                txtVendor.BackColor = System.Drawing.Color.White;
                tipVendor.RemoveAll();
                blnValid[3] = true;
            }
            // validate cost
            if (!validateMoney(txtCost.Text))
            {
                txtCost.BackColor = System.Drawing.Color.LightSalmon;
                tipCost.SetToolTip(txtCost, "Please enter a valid amount (1.99)");
                blnValid[4] = false;
            }
            else
            {
                txtCost.Text = Math.Round(double.Parse(txtCost.Text),2).ToString();
                txtCost.BackColor = System.Drawing.Color.White;
                tipCost.RemoveAll();
                blnValid[4] = true;
            }
            // validate qty
            if (!validateQty(txtQty.Text))
            {
                txtQty.BackColor = System.Drawing.Color.LightSalmon;
                tipQty.SetToolTip(txtQty, "Please enter numbers only");
                blnValid[5] = false;
            }
            else
            {
                txtQty.BackColor = System.Drawing.Color.White;
                tipQty.RemoveAll();
                blnValid[5] = true;
            }
            // validate price
            if (!validateMoney(txtPrice.Text))
            {
                txtPrice.BackColor = System.Drawing.Color.LightSalmon;
                tipPrice.SetToolTip(txtPrice, "Please enter a valid amount (1.99)");
                blnValid[6] = false;
            }
            else
            {
                txtPrice.Text = Math.Round(double.Parse(txtPrice.Text),2).ToString();
                txtPrice.BackColor = System.Drawing.Color.White;
                tipPrice.RemoveAll();
                blnValid[6] = true;
            }

            for (int i = 0; i < 7; i++)
            {
                if (!blnValid[i])
                {
                    return false;
                }
            }
            return true;
        }

        private bool validateMoney(string money)
        {
            try
            {
                Math.Round(double.Parse(money), 2);
                return true;
            }
            catch
            {
                return false;
            }
        }

        private bool validateQty(string qty)
        {
            // verify the qty is not empty
            if (!String.IsNullOrEmpty(qty))
            {
                for (int i = 0; i < qty.Length; i++)
                {
                    // verify only numbers were entered
                    if (!char.IsDigit(qty[i]))
                    {
                        return false;
                    }
                }
                return true;
            }
            txtQty.Text = "1";
            return true;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (validateForm())
            {
                if (candy.id > 0)
                {
                    updateCandy();
                    // update record
                    db.UpdateInventory(candy);
                }
                else
                {
                    // create record
                    db.AddCandy(buildCandy(txtName.Text));
                }
                // refresh datatable & dgv
                db.GetInventory();
                dgv.DataSource = db.dtInventory;
                dgv.ClearSelection();
                btnDelete.Enabled = true;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to delete the selected item?",
                "Delete?", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                db.DeleteInvItem(candy.id);
                dgv.DataSource = null;
                db.GetInventory();
                dgv.DataSource = db.dtInventory;
                dgv.ClearSelection();
                resetForm();
                btnDelete.Enabled = false; 
            }

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            db.searchDGV(dgv, txtSearch.Text);
            if (dgv.CurrentCell != null)
            {
                buildCandy();
                populateForm();
                btnDelete.Enabled = true;
            }

        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            resetForm();
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            resetForm();
        }
    }
}
