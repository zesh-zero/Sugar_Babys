﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sugar_babys.Screens
{
    public partial class CustomerScreen : Form
    {
        bool[] blnValid = new bool[11];
        static BasePerson person = new BasePerson();
        public Customer customer = new Customer(person);
        public Database db = new Database();
        // tooltips
        ToolTip tipName = new ToolTip();
        ToolTip tipEmail = new ToolTip();
        ToolTip tipPhone = new ToolTip();
        ToolTip tipAddress = new ToolTip();
        ToolTip tipAddress2 = new ToolTip();
        ToolTip tipCity = new ToolTip();
        ToolTip tipState = new ToolTip();
        ToolTip tipZip = new ToolTip();
        ToolTip tipContact = new ToolTip();
        ToolTip tipCemail = new ToolTip();
        ToolTip tipCphonel = new ToolTip();

        public CustomerScreen(DataTable dt)
        {
            InitializeComponent();

            dgv.DataSource = dt;
            db.formatDGV(dgv);
            populateStates();
            btnDelete.Enabled = false;
        }

        public CustomerScreen(DataTable dt, Customer customer)
        {
            InitializeComponent();
            this.customer = customer;
            dgv.DataSource = dt;
            db.formatDGV(dgv);
            populateStates();
            populateForm();
        }

        private void populateStates()
        {
            cboState.Items.Add("Alabama - AL");
            cboState.Items.Add("Alaska - AK");
            cboState.Items.Add("Arizona - AZ");
            cboState.Items.Add("Arkansas - AR");
            cboState.Items.Add("California - CA");
            cboState.Items.Add("Colorado - CO");
            cboState.Items.Add("Connecticut - CT");
            cboState.Items.Add("Delaware - DE");
            cboState.Items.Add("Florida - FL");
            cboState.Items.Add("Georgia - GA");
            cboState.Items.Add("Hawaii - HI");
            cboState.Items.Add("Idaho - ID");
            cboState.Items.Add("Illinois - IL");
            cboState.Items.Add("Indiana - IN");
            cboState.Items.Add("Iowa - IA");
            cboState.Items.Add("Kansas - KS");
            cboState.Items.Add("Kentucky - KY");
            cboState.Items.Add("Louisiana - LA");
            cboState.Items.Add("Maine - ME");
            cboState.Items.Add("Maryland - MD");
            cboState.Items.Add("Massachusetts - MA");
            cboState.Items.Add("Michigan - MI");
            cboState.Items.Add("Minnesota - MN");
            cboState.Items.Add("Mississippi - MS");
            cboState.Items.Add("Missouri - MO");
            cboState.Items.Add("Montana - MT");
            cboState.Items.Add("Nebraska - NE");
            cboState.Items.Add("Nevada - NV");
            cboState.Items.Add("New Hampshire - NH");
            cboState.Items.Add("New Jersey - NJ");
            cboState.Items.Add("New Mexico - NM");
            cboState.Items.Add("New York - NY");
            cboState.Items.Add("North Carolina - NC");
            cboState.Items.Add("North Dakota - ND");
            cboState.Items.Add("Ohio - OH");
            cboState.Items.Add("Oklahoma - OK");
            cboState.Items.Add("Oregon - OR");
            cboState.Items.Add("Pennsylvania - PA");
            cboState.Items.Add("Rhode Island - RI");
            cboState.Items.Add("South Carolina - SC");
            cboState.Items.Add("South Dakota - SD");
            cboState.Items.Add("Tennessee - TN");
            cboState.Items.Add("Texas - TX");
            cboState.Items.Add("Utah - UT");
            cboState.Items.Add("Vermont - VT");
            cboState.Items.Add("Virginia - VA");
            cboState.Items.Add("Washington - WA");
            cboState.Items.Add("West Virginia - WV");
            cboState.Items.Add("Wisconsin - WI");
            cboState.Items.Add("Wyoming - WY");
        }

        private void populateForm()
        {
            txtName.Text = customer.getName();
            txtAddress.Text = customer.getAddress1();
            txtAddress2.Text = customer.getAddress2();
            txtCity.Text = customer.getCity();
            cboState.SelectedItem = customer.getState();
            txtZip.Text = customer.getZip().ToString();
            if (txtZip.Text == "0") { txtZip.Text = ""; }
            txtPhone.Text = customer.getPhone().ToString();
            if (txtPhone.Text == "0") { txtPhone.Text = ""; }
            txtEmail.Text = customer.getEmail();
            txtContact.Text = customer.getContact();
            txtContactPhone.Text = customer.getContactPhone().ToString();
            if (txtContactPhone.Text == "0") { txtContactPhone.Text = ""; }
            txtContactEmail.Text = customer.getContactEmail();
        }

        private void updateData()
        {
            customer.setName(txtName.Text);
            customer.setAddress1(txtAddress.Text);
            customer.setAddress2(txtAddress2.Text);
            customer.setCity(txtCity.Text);
            customer.setState(cboState.SelectedItem.ToString());
            customer.setZip(Int32.Parse(txtZip.Text));
            customer.setPhone(Int64.Parse(txtPhone.Text));
            customer.setEmail(txtEmail.Text);
            customer.setContact(txtContact.Text);
            if (txtContactPhone.Text.Trim() != "")
            {
                customer.setContactPhone(Int64.Parse(txtContactPhone.Text));
            }
            customer.setContactEmail(txtContactEmail.Text);
        }

        public void buildCustomer()
        {
            // build customer
            customer = new Customer(person);
            DataRow row = ((DataTable)dgv.DataSource).Rows[dgv.CurrentCell.RowIndex];
            customer.setID((int)row["id"]);
            customer.setName((string)row["name"]);
            customer.setAddress1((string)row["address1"]);
            customer.setAddress2((string)row["address2"]);
            customer.setCity((string)row["city"]);
            customer.setState((string)row["state"]);
            customer.setZip((int)row["zip"]);
            customer.setPhone(Int64.Parse(row["phone"].ToString()));
            customer.setEmail((string)row["email"]);
            customer.setContact((string)row["contact"]);
            customer.setContactPhone(Int64.Parse(row["contactPhone"].ToString()));
            customer.setContactEmail((string)row["contactEmail"]);
            customer.setAnniversary((DateTime)row["anniversary"]);
            customer.setLastUpdated((DateTime)row["lastUpdated"]);
        }

        public void resetForm()
        {
            if (txtName.Text.Trim() != "" || txtPhone.Text.Trim() != "" || txtEmail.Text.Trim() != "" ||
                txtAddress.Text.Trim() != "" || txtAddress2.Text.Trim() != "" || txtCity.Text.Trim() != "" ||
                cboState.SelectedIndex > 0 || txtZip.Text.Trim() != "" || txtContact.Text.Trim() != "" ||
                txtContactPhone.Text.Trim() != "" || txtContactEmail.Text.Trim() != "")
            {
                DialogResult result = MessageBox.Show("Are you sure you want to reset the form?", "Reset?",
                    MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    customer = new Customer(person);
                    populateForm();
                    dgv.ClearSelection();
                    btnDelete.Enabled = false;
                }
            }
            else
            {
                customer = new Customer(person);
                populateForm();
                dgv.ClearSelection();
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (validateForm())
            {
                if (customer.getID() > 0)
                {
                    // update record
                    updateData();
                    db.UpdateCustomer(customer);
                }
                else
                {
                    // create record
                    updateData();
                    db.AddCustomer(customer);
                }
                // refresh datatable & dgv
                db.GetCustomers();
                dgv.DataSource = null;
                dgv.DataSource = db.dtCustomers;
                dgv.ClearSelection();
                //db.selectDGV(dgv, customer);
                btnDelete.Enabled = true;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            resetForm();
        }

        private void dgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgv.CurrentCell != null)
            {
                dgv.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.Yellow;
                buildCustomer();
                populateForm();
                btnDelete.Enabled = true;
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            db.searchDGV(dgv, txtSearch.Text);
            if (dgv.CurrentCell != null)
            {
                buildCustomer();
                populateForm();
                btnDelete.Enabled = true;
            }
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            resetForm();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to delete the selected customer " +
                "and all associated orders?", "Delete?", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                db.DeleteCustomer(customer.getID());
                customer = new Customer(person);
                db.dtCustomers = new DataTable();
                db.GetCustomers();
                dgv.ClearSelection();
                dgv.DataSource = null;
                dgv.Refresh();
                dgv.DataSource = db.dtCustomers;
                db.formatDGV(dgv);
                populateForm();
            }
        }

        private bool validateText(string text)
        {
            // verify the text is not empty
            if (!String.IsNullOrEmpty(text))
            {
                for (int i = 0; i < text.Length; i++)
                {
                    // verify only letters and numbers were entered
                    if (!char.IsLetterOrDigit(text[i]))
                    {
                        if (!char.IsWhiteSpace(text[i]))
                        {
                            return false;
                        }
                    }
                }
                return true;
            }
            return false;
        }

        private bool validateForm()
        {
            // validate name
            if (!validateText(txtName.Text))
            {
                txtName.BackColor = System.Drawing.Color.LightSalmon;
                tipName.SetToolTip(txtName, "Please enter letters and numbers only");
                blnValid[0] = false;
            }
            else
            {
                txtName.BackColor = System.Drawing.Color.White;
                tipName.RemoveAll();
                blnValid[0] = true;
            }
            // validate email
            if (!validateEmail(txtEmail.Text))
            {
                txtEmail.BackColor = System.Drawing.Color.LightSalmon;
                tipEmail.SetToolTip(txtEmail, "Please enter a valid email address (sample@email.com)");
                blnValid[1] = false;
            }
            else
            {
                txtEmail.BackColor = System.Drawing.Color.White;
                tipEmail.RemoveAll();
                blnValid[1] = true;
            }
            // validate phone
            if (!validatePhone(txtPhone.Text))
            {
                txtPhone.BackColor = System.Drawing.Color.LightSalmon;
                tipPhone.SetToolTip(txtPhone, "Please enter 10 numbers only");
                blnValid[2] = false;
            }
            else
            {
                txtPhone.BackColor = System.Drawing.Color.White;
                tipPhone.RemoveAll();
                blnValid[2] = true;
            }
            // validate address
            if (!validateText(txtAddress.Text))
            {
                txtAddress.BackColor = System.Drawing.Color.LightSalmon;
                tipAddress.SetToolTip(txtAddress, "Please enter letters and numbers only");
                blnValid[3] = false;
            }
            else
            {
                txtAddress.BackColor = System.Drawing.Color.White;
                tipAddress.RemoveAll();
                blnValid[3] = true;
            }
            // validate address2
            if (txtAddress2.Text.Trim() != "")
            {
                if (!validateText(txtAddress.Text))
                {
                    txtAddress2.BackColor = System.Drawing.Color.LightSalmon;
                    tipAddress2.SetToolTip(txtAddress2, "Please enter letters and numbers only");
                    blnValid[4] = false;
                }
                else
                {
                    txtAddress2.BackColor = System.Drawing.Color.White;
                    tipAddress2.RemoveAll();
                    blnValid[4] = true;
                }
            }
            else
            {
                txtAddress2.BackColor = System.Drawing.Color.White;
                tipAddress2.RemoveAll();
                blnValid[4] = true;
            }
            // validate city
            if (!validateText(txtCity.Text))
            {
                txtCity.BackColor = System.Drawing.Color.LightSalmon;
                tipCity.SetToolTip(txtCity, "Please enter letters and numbers only");
                blnValid[5] = false;
            }
            else
            {
                txtCity.BackColor = System.Drawing.Color.White;
                tipCity.RemoveAll();
                blnValid[5] = true;
            }
            // validate state
            if (cboState.SelectedIndex < 0)
            {
                cboState.BackColor = System.Drawing.Color.LightSalmon;
                tipState.SetToolTip(txtCity, "Please select a state");
                blnValid[6] = false;
            }
            else
            {
                cboState.BackColor = System.Drawing.Color.White;
                tipState.RemoveAll();
                blnValid[6] = true;
            }
            // validate zip
            if (!validateZip(txtZip.Text))
            {
                txtZip.BackColor = System.Drawing.Color.LightSalmon;
                tipZip.SetToolTip(txtZip, "Please enter 5 to 15 numbers only");
                blnValid[7] = false;
            }
            else
            {
                txtZip.BackColor = System.Drawing.Color.White;
                tipZip.RemoveAll();
                blnValid[7] = true;
            }
            // validate contact name
            if (txtContact.Text.Trim() != "")
            {
                if (!validateText(txtContact.Text))
                {
                    txtContact.BackColor = System.Drawing.Color.LightSalmon;
                    tipContact.SetToolTip(txtContact, "Please enter 10 numbers only");
                    blnValid[8] = false;
                }
                else
                {
                    txtContactPhone.BackColor = System.Drawing.Color.White;
                    tipContact.RemoveAll();
                    blnValid[8] = true;
                }
            }
            else
            {
                txtContact.BackColor = System.Drawing.Color.White;
                tipContact.RemoveAll();
                blnValid[8] = true;
            }
            // validate contact email
            if (txtContactEmail.Text.Trim() != "")
            {
                if (!validateEmail(txtContactEmail.Text))
                {
                    txtContactEmail.BackColor = System.Drawing.Color.LightSalmon;
                    tipCemail.SetToolTip(txtContactEmail, "Please enter a valid email address (sample@email.com)");
                    blnValid[9] = false;
                }
                else
                {
                    txtContactEmail.BackColor = System.Drawing.Color.White;
                    tipCemail.RemoveAll();
                    blnValid[9] = true;
                }
            }
            else
            {
                txtContactEmail.BackColor = System.Drawing.Color.White;
                tipCemail.RemoveAll();
                blnValid[9] = true;
            }
            // validate contact phone
            if (txtContactPhone.Text.Trim() != "")
            {
                if (!validatePhone(txtContactPhone.Text))
                {
                    txtContactPhone.BackColor = System.Drawing.Color.LightSalmon;
                    tipCphonel.SetToolTip(txtContactPhone, "Please enter 10 numbers only");
                    blnValid[10] = false;
                }
                else
                {
                    txtContactPhone.BackColor = System.Drawing.Color.White;
                    tipCphonel.RemoveAll();
                    blnValid[10] = true;
                }
            }
            else
            {
                txtContactPhone.Text = "";
                txtContactPhone.BackColor = System.Drawing.Color.White;
                tipCphonel.RemoveAll();
                blnValid[10] = true;
            }

            for (int i = 0; i < 11; i++)
            {
                if (!blnValid[i])
                {
                    return false;
                }
            }
            return true;
        }

        private bool validateZip(string zip)
        {
            // verify the zip is not empty
            if (!String.IsNullOrEmpty(zip))
            {
                // verify between 5 and 15 characters
                if (zip.Length >= 5 && zip.Length <= 15)
                {
                    for (int i = 0; i < zip.Length; i++)
                    {
                        // verify only numbers were entered
                        if (!char.IsDigit(zip[i]))
                        {
                            return false;
                        }
                    }
                    return true;
                }
            }
            return false;
        }

        private bool validatePhone(string phone)
        {
            // verify the phone is not empty
            if (!String.IsNullOrEmpty(phone))
            {
                // verify 10 characters
                if (phone.Length == 10)
                {
                    for (int i = 0; i < phone.Length; i++)
                    {
                        // verify only numbers were entered
                        if (!char.IsDigit(phone[i]))
                        {
                            return false;
                        }
                    }
                    return true;
                }
            }
            return false;
        }

        private bool validateEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            txtName.BackColor = System.Drawing.Color.White;
            tipName.RemoveAll();
        }

        private void txtEmail_TextChanged(object sender, EventArgs e)
        {
            txtEmail.BackColor = System.Drawing.Color.White;
            tipEmail.RemoveAll();
        }

        private void txtPhone_TextChanged(object sender, EventArgs e)
        {
            txtPhone.BackColor = System.Drawing.Color.White;
            tipPhone.RemoveAll();
        }

        private void txtAddress_TextChanged(object sender, EventArgs e)
        {
            txtAddress.BackColor = System.Drawing.Color.White;
            tipAddress.RemoveAll();
        }

        private void txtAddress2_TextChanged(object sender, EventArgs e)
        {
            txtAddress2.BackColor = System.Drawing.Color.White;
            tipAddress2.RemoveAll();
        }

        private void txtCity_TextChanged(object sender, EventArgs e)
        {
            txtCity.BackColor = System.Drawing.Color.White;
            tipCity.RemoveAll();
        }

        private void txtContact_TextChanged(object sender, EventArgs e)
        {
            txtContact.BackColor = System.Drawing.Color.White;
            tipContact.RemoveAll();
        }

        private void txtContactEmail_TextChanged(object sender, EventArgs e)
        {
            txtContactEmail.BackColor = System.Drawing.Color.White;
            tipCemail.RemoveAll();
        }

        private void txtContactPhone_TextChanged(object sender, EventArgs e)
        {
            txtContactPhone.BackColor = System.Drawing.Color.White;
            tipCphonel.RemoveAll();
        }

        private void cboState_MouseClick(object sender, MouseEventArgs e)
        {
            cboState.BackColor = System.Drawing.Color.White;
            tipState.RemoveAll();
        }

        private void txtZip_TextChanged(object sender, EventArgs e)
        {
            txtZip.BackColor = System.Drawing.Color.White;
            tipZip.RemoveAll();
        }
    }
}
