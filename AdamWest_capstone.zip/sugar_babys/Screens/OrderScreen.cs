﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sugar_babys.Screens
{
    public partial class OrderScreen : Form
    {
        string strAdjustment = "";
        bool blnNegative = false;
        List<OrderDetails> orderDetails = new List<OrderDetails>();
        DataTable dtCustomers = new DataTable();
        DataTable dtInventory = new DataTable();
        Order order = new Order();
        DataTable dtOrder = new DataTable();
        Database db = new Database();

        public OrderScreen(DataTable dtCustomers, DataTable dtInventory)
        {
            InitializeComponent();

            this.dtCustomers = dtCustomers;
            this.dtInventory = dtInventory;
            cboCustomer.DataSource = dtCustomers;
            cboInventory.DataSource = dtInventory;
            cboCustomer.ValueMember = "name";
            cboInventory.ValueMember = "name";
            db.formatDGV(dgvOrder);
            dgvOrder.Columns.Add("Item", "Item");
            dgvOrder.Columns.Add("Qty", "Qty");
            dgvOrder.Columns.Add("Price", "Price");
        }

        private void AddItem()
        {
            // build item
            Candy candy = new Candy();
            DataRow row = ((DataTable)cboInventory.DataSource).Rows[cboInventory.SelectedIndex];
            candy.id = ((int)row["id"]);
            candy.name = ((string)row["name"]);
            candy.description = (string)row["description"];
            candy.type = (string)row["type"];
            candy.vendor = (string)row["vendor"];
            if (txtQty.Text.Trim() == "")
            {
                candy.quantity = 1;
            }
            else if (ValidateNumber(txtQty.Text))
            {
                candy.quantity = Int32.Parse(txtQty.Text.Trim());
            }
            candy.cost = ((double)row["cost"] * candy.quantity);
            candy.price = ((double)row["price"] * candy.quantity);

            candy.firstPurchase = (DateTime)row["firstPurchase"];
            candy.lastPurchase = (DateTime)row["lastPurchase"];

            // add to dgv
            dgvOrder.Rows.Add(candy.name, candy.quantity, candy.price);
            buildOrderDetail(candy.id, candy.quantity);
        }

        private bool ValidateNumber(string text)
        {
            // verify the text is not empty
            if (!String.IsNullOrEmpty(text))
            {
                for (int i = 0; i < text.Length; i++)
                {
                    // verify only numbers were entered
                    if (!char.IsDigit(text[i]))
                    {
                        return false;
                    }
                }
                return true;
            }
            return false;
        }

        private bool ValidateAmount(string text)
        {
            strAdjustment = "";
            // verify the text is not empty
            if (!String.IsNullOrEmpty(text))
            {
                // check to see if a negative sign
                if (text.Trim()[0].ToString() == "-")
                {
                    // if so, remove it
                    blnNegative = true;
                    for (int i = 1; i < text.Length; i++)
                    {
                        strAdjustment = strAdjustment + text[i].ToString();
                    }
                }
                else
                {
                    blnNegative = false;
                    strAdjustment = text.Trim();
                }

                int d = 0;
                for (int i = 0; i < strAdjustment.Length; i++)
                {
                    // verify only numbers and/or one decimal were entered
                    if (!char.IsDigit(strAdjustment[i]))
                    {
                        if (strAdjustment[i].ToString() == "." && d <= 1)
                        {
                            d += 1;
                        }
                        else
                        {
                            return false;
                        }
                    }
                }
                return true;
            }
            return false;
        }

        private void UpdateTotals()
        {
            double subtotal = 0;
            double adjustment = 0;
            try
            {
                if (txtAdjustment.Text.Trim() != "" && ValidateAmount(txtAdjustment.Text.Trim()))
                {
                    adjustment = Math.Round(Double.Parse(strAdjustment), 2);
                }
            }
            catch
            {
                adjustment = 0;
                MessageBox.Show("Adjustment error - Please enter a valid adjustment (-1.00, 2.99");
            }

            foreach (DataGridViewRow row in dgvOrder.Rows)
            {
                // add to subtotal
                subtotal += (double)row.Cells[2].Value;
            }
            double tax = 0;
            double total = 0;
            if (blnNegative)
            {
                tax = Math.Round((subtotal - adjustment) * .07, 2);
                total = Math.Round(subtotal - adjustment + tax, 2);
            }
            else
            {
                tax = Math.Round((subtotal + adjustment) * .07, 2);
                total = Math.Round(subtotal + adjustment + tax, 2);
            }
            txtSubtotal.Text = subtotal.ToString();
            txtTax.Text = tax.ToString();
            txtTotal.Text = total.ToString();            
        }

        private void buildOrder()
        {
            // get customer id
            DataRow row = ((DataTable)cboCustomer.DataSource).Rows[cboCustomer.SelectedIndex];
            order.cusID = ((int)row["id"]);
            order.subtotal = Double.Parse(txtSubtotal.Text);
            try
            {
                if (txtAdjustment.Text.Trim() != "")
                {
                    if (blnNegative)
                    {
                        order.adjustment = -(Double.Parse(strAdjustment));
                    }
                    else
                    {
                        order.adjustment = Double.Parse(strAdjustment);
                    }
                }
                else
                {
                    order.adjustment = 0;
                }
            }
            catch
            {
                txtAdjustment.Text = "";
                order.adjustment = 0;
                MessageBox.Show("Adjustment error - adjustment amount was not valid");
            }
            order.tax = Double.Parse(txtTax.Text);
            order.total = Double.Parse(txtTotal.Text);
            order.notes = txtNotes.Text;
        }

        private void buildOrderDetail(int id, int qty)
        {
            OrderDetails orderDetail = new OrderDetails();
            orderDetail.invID = id;
            orderDetail.qty = qty;
            orderDetails.Add(orderDetail);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            AddItem();
            UpdateTotals();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            buildOrder();
            db.AddOrder(order, orderDetails);
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dgvOrder.CurrentCell != null)
            {
                orderDetails.RemoveAt(dgvOrder.CurrentRow.Index);
                dgvOrder.Rows.Remove(dgvOrder.CurrentRow);
                dgvOrder.ClearSelection();
            }
        }

        private void dgvOrder_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvOrder.CurrentCell != null)
            {
                dgvOrder.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.Yellow;
            }
        }

        private void txtAdjustment_Leave(object sender, EventArgs e)
        {
            UpdateTotals();
        }
    }
}
