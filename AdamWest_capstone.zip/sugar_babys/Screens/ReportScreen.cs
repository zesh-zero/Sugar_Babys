﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sugar_babys.Screens
{
    public partial class ReportScreen : Form
    {
        Database db = new Database();

        public ReportScreen()
        {
            InitializeComponent();
            db.GetDatabase();

            loadOrderDetails();
            loadEmployeeList();
            loadCustomerList();
        }

        public void loadCustomerList()
        {
            // print header
            txtCustomerList.Text = "Report: Customer List  |  " + DateTime.Now + "\r\n\r\n\t";

            foreach (DataRow c in db.dtCustomers.Rows)
            {
                txtCustomerList.Text = txtCustomerList.Text + c["name"] + "\r\n\t";
            }

            // print footer
            txtCustomerList.Text = txtCustomerList.Text + "\r\n\n\n*End of Report";
        }

        public void loadEmployeeList()
        {
            // print header
            txtEmployeeList.Text = "Report: Employee List  |  " + DateTime.Now + "\r\n\r\n\t";

            foreach (DataRow e in db.dtEmployees.Rows)
            {
                txtEmployeeList.Text = txtEmployeeList.Text + e["name"] + "\r\n\t";
            }

            // print footer
            txtEmployeeList.Text = txtEmployeeList.Text + "\r\n\n\n*End of Report";
        }


        public void loadOrderDetails()
        {
            // print header
            txtOrderDetails.Text = "Report: Order Details  |  " + DateTime.Now + "\r\n\r\n";

            foreach (DataRow o in db.dtOrders.Rows)
            {
                db.GetOrderDetails((int)o["id"]);
                txtOrderDetails.Text = txtOrderDetails.Text + "Order #  " + o["id"] + "  |  Date: " +
                    o["purchaseDate"] + "  |  ";
                // get customer name
                foreach (DataRow c in db.dtCustomers.Rows)
                {
                    if ((int)c["id"] == (int)o["cusID"])
                    {
                        txtOrderDetails.Text = txtOrderDetails.Text + "Customer: " + c["name"] + 
                            "\r\n\r\n\t";
                    }
                }
                // get order details
                foreach (DataRow d in db.dtOrderDetails.Rows)
                {
                    if ((int)d["ordID"] == (int)o["id"])
                    {
                        // get item details
                        foreach (DataRow i in db.dtInventory.Rows)
                        {
                            if ((int)i["id"] == (int)d["invID"])
                            {
                                txtOrderDetails.Text = txtOrderDetails.Text + "Item: " + i["name"] +
                                    " , Qty: " + d["qty"] + "\r\n\t";
                            }
                        }
                    }
                }
                txtOrderDetails.Text = txtOrderDetails.Text + "\r\n\tSubtotal: " + o["subtotal"] + "\r\n\t";
                txtOrderDetails.Text = txtOrderDetails.Text + "Adjustment: " + o["adjustment"] + "\r\n\t";
                txtOrderDetails.Text = txtOrderDetails.Text + "Tax: " + o["tax"] + "\r\n\t";
                txtOrderDetails.Text = txtOrderDetails.Text + "Total: " + o["total"] + "\r\n\r\n\t";
                txtOrderDetails.Text = txtOrderDetails.Text + "Notes: " + o["notes"] + "\r\n\r\n\r\n";
            }

            // print footer
            txtOrderDetails.Text = txtOrderDetails.Text + "\r\n\n\n*End of Report";
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
