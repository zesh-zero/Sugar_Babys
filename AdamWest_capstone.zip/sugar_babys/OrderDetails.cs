﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sugar_babys
{
    public class OrderDetails
    {
        public int invID { get; set; }
        public int ordID { get; set; }
        public int qty { get; set; }
    }
}
