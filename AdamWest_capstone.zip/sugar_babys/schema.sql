use freedbtech_sugarbaby;

-- reset everything
drop table orderDetails;
drop table orders;
drop table employees;
drop table customers;
drop table inventory;

create table customers (id int auto_increment primary key,
						name varchar (50) not null,
                        address1 varchar (50) not null,
                        address2 varchar (50),
                        city varchar (50) not null,
                        state varchar (50) not null,
                        zip int not null,
                        phone long not null,
                        email varchar (50) not null,
                        contact varchar (50),
                        contactPhone long,
                        contactEmail varchar(50),
                        anniversary datetime not null,
                        lastUpdated datetime not null);
                        
create table employees (id int auto_increment primary key,
						name varchar (50) not null,
                        address1 varchar (50) not null,
                        address2 varchar (50),
                        city varchar (50) not null,
                        state varchar (50) not null,
                        zip int not null,
                        phone long not null,
                        email varchar (50) not null,
                        jobTitle varchar (50) not null,
                        salary int not null,
                        anniversary datetime not null,
                        lastUpdated datetime not null);
                
create table inventory (id int auto_increment primary key,
						name varchar (50) not null,
                        description varchar (50) not null,
                        type varchar (50),
                        vendor varchar (50) not null,
                        cost double not null,
                        price double not null,
                        qty int not null,
                        firstPurchase datetime not null,
                        lastPurchase datetime not null);
                        
create table orders (id int auto_increment primary key,
					cusID int not null,
                    subtotal double not null,
                    adjustment double,
                    tax double not null,
                    total double not null,
                    notes varchar (500),
                    purchaseDate datetime not null,
                    foreign key (cusID) references customers (id));

create table orderDetails (invID int not null,
						   ordID int not null,
						   qty int not null);

-- insert sample data
insert into customers (name, address1, address2, city, state, zip, phone, email, contact, 
						contactPhone, contactEmail, anniversary, lastUpdated) values 
                        ('Sample Customer', '123 Sample Address', 'Apt 200', 'Faketown',
                         'Georgia - GA', 33333, 5051234567, 'sample@customer.net',
                         'Sample Contact', 5053210987, 'sample@contact.org', now(), now());
                         
insert into employees (name, address1, address2, city, state, zip, phone, email, 
						jobTitle, salary, anniversary, lastUpdated) values 
					    ('Sample Employee', '456 Sample Address', 'Suite A', 'Faketown',
						 'Georgia - GA', 33333, 5056789435, 'sample@employee.net',
					     'Sample Title', 50000, now(), now());
                         
insert into inventory (name, description, type, vendor, cost, price, qty, firstPurchase,
						lastPurchase) values ('Candy 1', 'chocolate candy bar', 
                        'candy bar', 'Sample Vendor', .50, 1.50, 200, now(), now());
                        
insert into orders (cusID, subtotal, adjustment, tax, total, notes, purchaseDate) values 
					(1, 15.00, -1.50, .95, 14.45, 'Sample notes for order 1', now());
                    
insert into orderDetails (invID, ordID, qty) values (1, 1, 10);