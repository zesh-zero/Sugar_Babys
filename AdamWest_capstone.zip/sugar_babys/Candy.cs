﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sugar_babys
{
    public class Candy
    {
        public int id { get; set; }
        public string name { get; set; }
        public string type { get; set; }
        public string description { get; set; }
        public string vendor { get; set; }
        public double cost { get; set; }
        public double price { get; set; }
        public int quantity { get; set; }
        public DateTime firstPurchase { get; set; }
        public DateTime lastPurchase { get; set; }
    }
}
