﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sugar_babys
{
    public class Customer : Person
    {
        public string contact;
        public string contactEmail;
        public long contactPhone;

        public Customer(BasePerson person)
        {
            setID(person.ID);
            setName(person.name);
            setAddress1(person.address1);
            setAddress2(person.address2);
            setCity(person.city);
            setState(person.state);
            setZip(person.zip);
            setPhone(person.phone);
            setEmail(person.email);
            setContact(contact);
            setContactPhone(contactPhone);
            setContactEmail(contactEmail);
            setAnniversary(person.anniversary);
            setLastUpdated(person.lastUpdated);
        }

        public string getContact()
        {
            return contact;
        }
        public long getContactPhone()
        {
            return contactPhone;
        }
        public string getContactEmail()
        {
            return contactEmail;
        }

        public void setContact(string contact)
        {
            this.contact = contact;
        }
        public void setContactPhone(long contactPhone)
        {
            this.contactPhone = contactPhone;
        }
        public void setContactEmail(string contactEmail)
        {
            this.contactEmail = contactEmail;
        }
    }
}
