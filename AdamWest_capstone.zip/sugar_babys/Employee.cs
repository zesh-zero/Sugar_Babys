﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sugar_babys
{
    public class Employee : Person
    {
        private double salary;
        private string jobTitle;

        public Employee(BasePerson person)
        {
            setID(person.ID);
            setName(person.name);
            setAddress1(person.address1);
            setAddress2(person.address2);
            setCity(person.city);
            setState(person.state);
            setZip(person.zip);
            setPhone(person.phone);
            setEmail(person.email);
            setJobTitle(jobTitle);
            setSalary(salary);
            setAnniversary(person.anniversary);
            setLastUpdated(person.lastUpdated);
        }

        public string getJobTitle()
        {
            return jobTitle;
        }
        public double getSalary()
        {
            return salary;
        }

        public void setJobTitle(string jobTitle)
        {
            this.jobTitle = jobTitle;
        }
        public void setSalary(double salary)
        {
            this.salary = salary;
        }
    }
}
