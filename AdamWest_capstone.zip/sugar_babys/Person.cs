﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sugar_babys
{
    public struct BasePerson
    {
        public int ID;
        public string name;
        public string address1;
        public string address2;
        public string city;
        public string state;
        public int zip;
        public long phone;
        public string email;
        public DateTime anniversary;
        public DateTime lastUpdated;
    }

    public abstract class Person
    {
        protected int aID;
        protected string aName;
        protected string aAddress1;
        protected string aAddress2;
        protected string aCity;
        protected string aState;
        protected int aZip;
        protected long aPhone;
        protected string aEmail;
        protected DateTime aAnniversary;
        protected DateTime aLastUpdated;

        public int getID()
        {
            return aID;
        }
        public string getName()
        {
            return aName;
        }
        public string getAddress1()
        {
            return aAddress1;
        }
        public string getAddress2()
        {
            return aAddress2;
        }
        public string getCity()
        {
            return aCity;
        }
        public string getState()
        {
            return aState;
        }
        public int getZip()
        {
            return aZip;
        }
        public long getPhone()
        {
            return aPhone;
        }
        public string getEmail()
        {
            return aEmail;
        }
        public DateTime getAnniversary()
        {
            return aAnniversary;
        }
        public DateTime getLastUpdated()
        {
            return aLastUpdated;
        }
        public void setID(int id)
        {
            aID = id;
        }
        public void setName(string name)
        {
            aName = name;
        }
        public void setAddress1(string address1)
        {
            aAddress1 = address1;
        }
        public void setAddress2(string address2)
        {
            aAddress2 = address2;
        }
        public void setCity(string city)
        {
            aCity = city;
        }
        public void setState(string state)
        {
            aState = state;
        }
        public void setZip(int zip)
        {
            aZip = zip;
        }
        public void setPhone(long phone)
        {
            aPhone = phone;
        }
        public void setEmail(string email)
        {
            aEmail = email;
        }
        public void setAnniversary(DateTime anniversary)
        {
            aAnniversary = anniversary;
        }
        public void setLastUpdated(DateTime lastUpdated)
        {
            aLastUpdated = lastUpdated;
        }
    }
}
