﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace sugar_babys
{
    public class Database
    {
        public DataTable dtCustomers = new DataTable();
        public DataTable dtEmployees = new DataTable();
        public DataTable dtOrders = new DataTable();
        public DataTable dtCustomerOrders = new DataTable();
        public DataTable dtOrderDetails = new DataTable();
        public DataTable dtInventory = new DataTable();
        public List<Customer> customers = new List<Customer>();

        public void GetDatabase()
        {
            MySqlConnection con = new MySqlConnection("server=freedb.tech;user id=freedbtech_sugarbaby;" +
                "password=doobydooby;persistsecurityinfo=True;database=freedbtech_sugarbaby");
            con.Open();
            // get customers
            string sqlString = "SELECT * FROM customers;";
            MySqlCommand cmd = new MySqlCommand(sqlString, con);
            MySqlDataAdapter adp = new MySqlDataAdapter(cmd);
            adp.Fill(dtCustomers);
            //get employees
            sqlString = "SELECT * FROM employees;";
            cmd = new MySqlCommand(sqlString, con);
            adp = new MySqlDataAdapter(cmd);
            adp.Fill(dtEmployees);
            // get orders
            sqlString = "SELECT * FROM orders;";
            cmd = new MySqlCommand(sqlString, con);
            adp = new MySqlDataAdapter(cmd);
            adp.Fill(dtOrders);
            // get inventory
            sqlString = "SELECT * FROM inventory;";
            cmd = new MySqlCommand(sqlString, con);
            adp = new MySqlDataAdapter(cmd);
            adp.Fill(dtInventory);
            con.Close();
        }

        public void GetOrdersCustomers()
        {
            dtCustomers = new DataTable();
            dtOrders = new DataTable();
            MySqlConnection con = new MySqlConnection("server=freedb.tech;user id=freedbtech_sugarbaby;" +
                 "password=doobydooby;persistsecurityinfo=True;database=freedbtech_sugarbaby");
            con.Open();
            // get customers
            string sqlString = "SELECT * FROM customers ORDER BY name ASC;";
            MySqlCommand cmd = new MySqlCommand(sqlString, con);
            MySqlDataAdapter adp = new MySqlDataAdapter(cmd);
            cmd = new MySqlCommand(sqlString, con);
            adp = new MySqlDataAdapter(cmd);
            adp.Fill(dtCustomers);
            sqlString = "SELECT * FROM orders;";
            cmd = new MySqlCommand(sqlString, con);
            adp = new MySqlDataAdapter(cmd);
            adp.Fill(dtOrders);
            con.Close();
        }

        public void GetCustomers()
        {
            dtCustomers = new DataTable();
            MySqlConnection con = new MySqlConnection("server=freedb.tech;user id=freedbtech_sugarbaby;" +
                 "password=doobydooby;persistsecurityinfo=True;database=freedbtech_sugarbaby");
            con.Open();
            // get customers
            string sqlString = "SELECT * FROM customers ORDER BY name ASC;";
            MySqlCommand cmd = new MySqlCommand(sqlString, con);
            MySqlDataAdapter adp = new MySqlDataAdapter(cmd);
            cmd = new MySqlCommand(sqlString, con);
            adp = new MySqlDataAdapter(cmd);
            adp.Fill(dtCustomers);
            con.Close();
        }

        public void GetEmployees()
        {
            dtEmployees = new DataTable();
            MySqlConnection con = new MySqlConnection("server=freedb.tech;user id=freedbtech_sugarbaby;" +
                 "password=doobydooby;persistsecurityinfo=True;database=freedbtech_sugarbaby");
            con.Open();
            // get employees
            string sqlString = "SELECT * FROM employees;";
            MySqlCommand cmd = new MySqlCommand(sqlString, con);
            MySqlDataAdapter adp = new MySqlDataAdapter(cmd);
            cmd = new MySqlCommand(sqlString, con);
            adp = new MySqlDataAdapter(cmd);
            adp.Fill(dtEmployees);
            con.Close();
        }

        public void GetInventory()
        {
            dtInventory = new DataTable();
            MySqlConnection con = new MySqlConnection("server=freedb.tech;user id=freedbtech_sugarbaby;" +
                 "password=doobydooby;persistsecurityinfo=True;database=freedbtech_sugarbaby");
            con.Open();
            // get inventory
            string sqlString = "SELECT * FROM inventory;";
            MySqlCommand cmd = new MySqlCommand(sqlString, con);
            MySqlDataAdapter adp = new MySqlDataAdapter(cmd);
            cmd = new MySqlCommand(sqlString, con);
            adp = new MySqlDataAdapter(cmd);
            adp.Fill(dtInventory);
            con.Close();
        }

        public void GetOrders(int cusID)
        {
            dtCustomerOrders = new DataTable();
            MySqlConnection con = new MySqlConnection("server=freedb.tech;user id=freedbtech_sugarbaby;" +
                 "password=doobydooby;persistsecurityinfo=True;database=freedbtech_sugarbaby");
            con.Open();
            // get orders
            string sqlString = "SELECT * FROM orders WHERE cusID = " + cusID + ";";
            MySqlCommand cmd = new MySqlCommand(sqlString, con);
            MySqlDataAdapter adp = new MySqlDataAdapter(cmd);
            cmd = new MySqlCommand(sqlString, con);
            adp = new MySqlDataAdapter(cmd);
            adp.Fill(dtCustomerOrders);
            con.Close();
        }

        public void GetOrders()
        {
            dtCustomerOrders = new DataTable();
            MySqlConnection con = new MySqlConnection("server=freedb.tech;user id=freedbtech_sugarbaby;" +
                 "password=doobydooby;persistsecurityinfo=True;database=freedbtech_sugarbaby");
            con.Open();
            // get orders
            string sqlString = "SELECT * FROM orders;";
            MySqlCommand cmd = new MySqlCommand(sqlString, con);
            MySqlDataAdapter adp = new MySqlDataAdapter(cmd);
            cmd = new MySqlCommand(sqlString, con);
            adp = new MySqlDataAdapter(cmd);
            adp.Fill(dtOrders);
            con.Close();
        }

        public void GetOrderDetails(Order order)
        {
            MySqlConnection con = new MySqlConnection("server=freedb.tech;user id=freedbtech_sugarbaby;" +
                 "password=doobydooby;persistsecurityinfo=True;database=freedbtech_sugarbaby");
            con.Open();
            // get order details
            string sqlString = "SELECT * FROM orderDetails WHERE ordID = " + order.id + ";";
            MySqlCommand cmd = new MySqlCommand(sqlString, con);
            MySqlDataAdapter adp = new MySqlDataAdapter(cmd);
            cmd = new MySqlCommand(sqlString, con);
            adp = new MySqlDataAdapter(cmd);
            adp.Fill(dtOrderDetails);
            con.Close();
        }

        public void GetOrderDetails(int id)
        {
            dtOrderDetails = new DataTable();
            MySqlConnection con = new MySqlConnection("server=freedb.tech;user id=freedbtech_sugarbaby;" +
                 "password=doobydooby;persistsecurityinfo=True;database=freedbtech_sugarbaby");
            con.Open();
            // get order details
            string sqlString = "SELECT * FROM orderDetails WHERE ordID = " + id + ";";
            MySqlCommand cmd = new MySqlCommand(sqlString, con);
            MySqlDataAdapter adp = new MySqlDataAdapter(cmd);
            cmd = new MySqlCommand(sqlString, con);
            adp = new MySqlDataAdapter(cmd);
            adp.Fill(dtOrderDetails);
            con.Close();
        }


        public void AddCustomer(Customer customer)
        {
            MySqlConnection con = new MySqlConnection("server=freedb.tech;user id=freedbtech_sugarbaby;" +
                "password=doobydooby;persistsecurityinfo=True;database=freedbtech_sugarbaby");
            con.Open();
            // add customer
            string sqlString = "INSERT INTO customers (name, address1, address2, city, state, zip, " +
                "phone, email, contact, contactPhone, contactEmail, anniversary, lastUpdated) " +
                "values ('" + customer.getName() + "', '" + customer.getAddress1() + "', '" + 
                customer.getAddress2() + "', '" + customer.getCity() + "', '" + customer.getState() + "', " +
                customer.getZip() + ", " + customer.getPhone() + ", '" + customer.getEmail() + "', '" + 
                customer.getContact() + "', " + customer.getContactPhone() + ", '" + customer.getContactEmail() + 
                "', NOW(), NOW());";
            MySqlCommand cmd = new MySqlCommand(sqlString, con);
            cmd.ExecuteNonQuery();
            customer.setID((int)cmd.LastInsertedId);
            con.Close();
        }

        public void UpdateCustomer(Customer customer)
        {
            MySqlConnection con = new MySqlConnection("server=freedb.tech;user id=freedbtech_sugarbaby;" +
                "password=doobydooby;persistsecurityinfo=True;database=freedbtech_sugarbaby");
            con.Open();
            // update customer
            string sqlString = "UPDATE customers SET name = '" + customer.getName() + "', " +
                "address1 = '" + customer.getAddress1() + "', address2 = '" + customer.getAddress2() +
                "', city = '" + customer.getCity() + "', state = '" + customer.getState() + "', zip = " +
                customer.getZip() + ", phone = " + customer.getPhone() + ", email = '" +
                customer.getEmail() + "', contact = '" + customer.getContact() + "', contactPhone = " +
                customer.getContactPhone() + ", contactEmail = '" + customer.getContactEmail() + "', " +
                " lastUpdated = NOW() WHERE id = " + customer.getID() + ";";
            MySqlCommand cmd = new MySqlCommand(sqlString, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void AddEmployee(Employee employee)
        {
            MySqlConnection con = new MySqlConnection("server=freedb.tech;user id=freedbtech_sugarbaby;" +
                "password=doobydooby;persistsecurityinfo=True;database=freedbtech_sugarbaby");
            con.Open();
            // add employee
            string sqlString = "INSERT INTO employees (name, address1, address2, city, state, zip, " +
                "phone, email, jobTitle, salary, anniversary, lastUpdated) values ('" + 
                employee.getName() + "', '" + employee.getAddress1() + "', '" + employee.getAddress2() + "', '" +
                employee.getCity() + "', '" + employee.getState() + "', " + employee.getZip() +
                ", " + employee.getPhone() + ", '" + employee.getEmail() + "', '" + 
                employee.getJobTitle() + "', " + employee.getSalary() + ", NOW(), NOW());";
            MySqlCommand cmd = new MySqlCommand(sqlString, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void UpdateEmployee(Employee employee)
        {
            MySqlConnection con = new MySqlConnection("server=freedb.tech;user id=freedbtech_sugarbaby;" +
                "password=doobydooby;persistsecurityinfo=True;database=freedbtech_sugarbaby");
            con.Open();
            // update employee
            string sqlString = "UPDATE employees SET name = '" + employee.getName() + "', " +
                "address1 = '" + employee.getAddress1() + "', address2 = '" + employee.getAddress2() +
                "', city = '" + employee.getCity() + "', state = '" + employee.getState() + "', zip = " +
                employee.getZip() + ", phone = " + employee.getPhone() + ", email = '" +
                employee.getEmail() + "', jobTitle = '" + employee.getJobTitle() + "', salary = " +
                employee.getSalary() + ", lastUpdated = NOW() WHERE id = " + employee.getID() + ";";
            MySqlCommand cmd = new MySqlCommand(sqlString, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void AddCandy(Candy candy)
        {
            MySqlConnection con = new MySqlConnection("server=freedb.tech;user id=freedbtech_sugarbaby;" +
                "password=doobydooby;persistsecurityinfo=True;database=freedbtech_sugarbaby");
            con.Open();
            // add candy
            string sqlString = "INSERT INTO inventory (name, description, type, vendor, cost, price, qty, " +
                "firstPurchase, lastPurchase) values ('" + candy.name + "', '" + candy.description +
                "', '" + candy.type + "', '" + candy.vendor + "', " + candy.cost + ", " + candy.price +
                ", " + candy.quantity + ", NOW(), NOW());";
            MySqlCommand cmd = new MySqlCommand(sqlString, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void UpdateInventory(Candy candy)
        {
            MySqlConnection con = new MySqlConnection("server=freedb.tech;user id=freedbtech_sugarbaby;" +
                "password=doobydooby;persistsecurityinfo=True;database=freedbtech_sugarbaby");
            con.Open();
            // update inventory
            string sqlString = "UPDATE inventory SET name = '" + candy.name + "', " +
                "description = '" + candy.description + "', type = '" + candy.type + "', vendor = '" + 
                candy.vendor + "', cost = " + candy.cost + ", price = " + candy.price + ", qty = " + 
                candy.quantity + ", lastPurchase = NOW() WHERE id = " + candy.id + ";";
            MySqlCommand cmd = new MySqlCommand(sqlString, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void AddOrder(Order order, List<OrderDetails> orderDetails)
        {
            MySqlConnection con = new MySqlConnection("server=freedb.tech;user id=freedbtech_sugarbaby;" +
                "password=doobydooby;persistsecurityinfo=True;database=freedbtech_sugarbaby");
            con.Open();
            // add order
            string sqlString = "INSERT INTO orders (cusID, subtotal, adjustment, tax, total, notes, " +
                "purchaseDate) values (" + order.cusID + ", " + order.subtotal + ", " + order.adjustment +
                ", " + order.tax + ", " + order.total + ", '" + order.notes + "', now());";
            MySqlCommand cmd = new MySqlCommand(sqlString, con);
            cmd.ExecuteNonQuery();
            // get order id
            order.id = (int)cmd.LastInsertedId;
            // add order details
            foreach (OrderDetails orderDetail in orderDetails)
            {
                sqlString = "INSERT INTO orderDetails (invID, ordID, qty) VALUES (" + orderDetail.invID +
                    ", " + order.id + ", " + orderDetail.qty + ");";
                cmd = new MySqlCommand(sqlString, con);
                cmd.ExecuteNonQuery();
            }
            con.Close();
        }

        public void DeleteCustomer(int id)
        {
            string sqlString;
            MySqlCommand cmd = new MySqlCommand();

            MySqlConnection con = new MySqlConnection("server=freedb.tech;user id=freedbtech_sugarbaby;" +
                "password=doobydooby;persistsecurityinfo=True;database=freedbtech_sugarbaby");
            con.Open();
            // get all order ids
            GetOrders(id);
            foreach (DataRow row in dtCustomerOrders.Rows)
            {
                int oID = (int)row["id"];
                // delete all associated orders
                sqlString = "DELETE FROM orderDetails WHERE ordID = " + oID + ";";
                cmd = new MySqlCommand(sqlString, con);
                var dw = cmd.ExecuteNonQuery();

                sqlString = "DELETE FROM orders WHERE id = " + oID + ";";
                cmd = new MySqlCommand(sqlString, con);
                dw = cmd.ExecuteNonQuery();
            }
            // delete customer
            sqlString = "DELETE FROM customers WHERE id = " + id + ";";
            cmd = new MySqlCommand(sqlString, con);
            var dw2 = cmd.ExecuteNonQuery();
            con.Close();
        }

        public void DeleteEmployee(Employee employee)
        {
            int id = employee.getID();
            string sqlString;
            MySqlCommand cmd = new MySqlCommand();

            MySqlConnection con = new MySqlConnection("server=freedb.tech;user id=freedbtech_sugarbaby;" +
                "password=doobydooby;persistsecurityinfo=True;database=freedbtech_sugarbaby");
            con.Open();
            // delete employee
            sqlString = "DELETE FROM employees WHERE id = " + id + ";";
            cmd = new MySqlCommand(sqlString, con);
            var dw2 = cmd.ExecuteNonQuery();
            con.Close();
        }


        public void DeleteOrder(int id)
        {
            MySqlConnection con = new MySqlConnection("server=freedb.tech;user id=freedbtech_sugarbaby;" +
                "password=doobydooby;persistsecurityinfo=True;database=freedbtech_sugarbaby");
            con.Open();
            // delete order details
            string sqlString = "DELETE FROM orderDetails WHERE ordID = " + id + ";";
            MySqlCommand cmd = new MySqlCommand(sqlString, con);
            var dw = cmd.ExecuteNonQuery();
            // delete order
            sqlString = "DELETE FROM orders WHERE id = " + id + ";";
            cmd = new MySqlCommand(sqlString, con);
            dw = cmd.ExecuteNonQuery();
            con.Close();
        }

        public void DeleteInvItem(int id)
        {
            MySqlConnection con = new MySqlConnection("server=freedb.tech;user id=freedbtech_sugarbaby;" +
                "password=doobydooby;persistsecurityinfo=True;database=freedbtech_sugarbaby");
            con.Open();
            // delete order details
            string sqlString = "DELETE FROM inventory WHERE id = " + id + ";";
            MySqlCommand cmd = new MySqlCommand(sqlString, con);
            var dw = cmd.ExecuteNonQuery();
            con.Close();
        }

        public void formatDGV(DataGridView d)
        {
            d.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            d.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.White;
            d.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            d.RowHeadersVisible = false;
            foreach (DataGridViewColumn column in d.Columns)
            {
                column.SortMode = DataGridViewColumnSortMode.NotSortable;
            }
            d.Refresh();
        }

        public void selectDGV(DataGridView d, Person p)
        {
            int id = p.getID();
            DataTable dt = new DataTable();
            dt = (DataTable)d.DataSource;
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if ((int)dt.Rows[i]["id"] == id)
                {
                    d.ClearSelection();
                    d.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.Yellow;
                    d.Rows[i].Selected = true;
                }
            }
        }

        public void searchDGV(DataGridView d, string search)
        {
            DataTable dt = new DataTable();
            dt = (DataTable)d.DataSource;
            if (search.Trim() != "")
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (dt.Rows[i]["name"].ToString().ToLower().Contains(search.Trim().ToLower()))
                    {
                        d.ClearSelection();
                        d.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.Yellow;
                        d.Rows[i].Selected = true;
                    }
                    else
                    {
                        d.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.White;
                        d.ClearSelection();
                    }
                }
            }
            else
            {
                d.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.White;
                d.ClearSelection();
            }
        }
    }
}
